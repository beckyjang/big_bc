#!/bin/bash
#
# Sync Gateway Policies with graphql -xv
# [Export from SourceGateway(Dev)]
# ./dev_to_prod.sh export gateway_XXX.properties | tee ./logs/gmu_d2p_$(date +"%Y%m%d").log
# [Import to TargetGateway(Prod/DR)]
# ./dev_to_prod.sh extract <gz filename relative path>
# ./dev_to_prod.sh import-test gateway_XXX.properties
# ./dev_to_prod.sh import-run gateway_XXX.properties

export GRAPHMAN_HOME=./graphman-client-main

########################################################################
# Gateway Folder name should be start with "@GT" (FolderPrefix)
# Resource Name should be start with "GT" (ResourceName)
# Add Extra Policy and Services when need
SourcePolicyName=()
SourceServiceName=()

SourceClusterPropertyName=("portal.account.plans.fragment.guid" "portal.api.folder" "portal.deployer.status")
SourceClusterPropertyName+=("io.xmlPartMaxBytes" "restman.request.message.maxSize")

SourceFolderName=("API Portal Integration" "Portal APIs" "Portal Custom Messages" ) # making folder
SourceByFolderPathName=("/API Portal Integration")  ## subfolders and policy/services

SourceServerModuleFileName=("ApiPortalIntegrationAssertion" "PortalDeployerAssertion" "PortalUpgradeAssertion")


# [Folder based Export]
DefaultDIR=workspace
MigWorkFolder=$DefaultDIR/working
ResourceName=GTC
FolderPrefix=@GTC


declare -A policyMap serviceMap encMap folderMap
declare -a SourcecwpParam SourceServiceId SourceFolderId
declare -a outputFileNames
########################################################################

# if [ -z "$GRAPHMAN_HOME" ]; then
#   echo "GRAPHMAN_HOME environment variable is not defined"
#   exit 1
# fi


job=$1
GatewayProfile=$2
startDate=$(date)
Today=$(date +"%Y-%m-%d")

if [[ "$GatewayProfile" == "" ]] ; then
    GatewayProfile="default"
fi

resultLog=${DefaultDIR}/result_${job}_${Today}.json


echo "INFO: GRAPHMAN_HOME=${GRAPHMAN_HOME}"
echo "INFO: GatewayProfile = ${GatewayProfile}"

function usages() {
    echo Usage:
    printf '  %s {export|extract|import-run} [<filename>]\n' $0

    echo Parameters:
    printf '  %-20s %s\n' "export" "Export and archive bundle and resources"
    printf '  %-20s %s\n' "extract <filename>" "Extract from archive file <filename>"
    printf '  %-20s %s\n' "import-run" "Import bundle file to the Gateway"

    echo Examples:
    printf '  %-20s %s\n'  $0 "export"
    printf '  %-20s %s\n'  $0 "extract ./archive/dapigw01-XXX.tar.gz"
    printf '  %-20s %s\n'  $0 "import-run"

    exit 1
}


function runGraphman {
    myCmd="\"${GRAPHMAN_HOME}/graphman.sh\" $1"
    echo INFO: Running... "$myCmd"

    std_err=$((
    (
        echo "${myCmd}" | sh
    )
    ) 2>&1)

    echo -e "${std_err}" >> ${resultLog}
    echo -e "INFO: Result..\n${std_err}"

    if echo -e "${std_err}" | grep "\"status\": \"ERROR\"" >/dev/null; then
        echo -e "\nERROR: Failed running! Please check ${resultLog} file.\n"
        exit 1
    else
        echo -e "\nINFO: Logged ${resultLog}.\n"
    fi
}

function export-bundle {
    echo "INFO: export resouces"
    echo "INFO: will remove existing directories : $MigWorkFolder"

    if [ -d "$MigWorkFolder" ] ; then
        rm -rf ./${MigWorkFolder}
    fi
    mkdir -p "$MigWorkFolder"
    rm -f ./${resultLog}

    ## Cluster Wide Properties
    if [ "${#SourceClusterPropertyName[@]}" -gt 0 ] ; then
        for name in "${SourceClusterPropertyName[@]}" ; do
            runGraphman "export --gateway ${GatewayProfile} --using clusterProperties --filter.by name --filter.equals '${name}' --output '${MigWorkFolder}/${name}.json'"
            outputFileNames+=( "${MigWorkFolder}/${name}.json" )
        done
    fi

    ## Folders
    if [ "${#SourceFolderName[@]}" -gt 0 ] ; then
        for name in "${SourceFolderName[@]}" ; do
            runGraphman "export --gateway ${GatewayProfile} --using folders --filter.by name --filter.equals '${name}' --output '${MigWorkFolder}/${name}.json'"
            outputFileNames+=( "${MigWorkFolder}/${name}.json" )
        done
    fi

    ## Server Module Files
    if [ "${#SourceServerModuleFileName[@]}" -gt 0 ] ; then
        for name in "${SourceServerModuleFileName[@]}" ; do
            runGraphman "export --gateway ${GatewayProfile} --using serverModuleFile --variables.name '${name}' --variables.includeModuleFilePart true --output '${MigWorkFolder}/${name}.json'"
            outputFileNames+=( "${MigWorkFolder}/${name}.json" )
        done
    fi

    ## Policy/Service/Enc by Folder Path
    if [ "${#SourceByFolderPathName[@]}" -gt 0 ] ; then
        for name in "${SourceByFolderPathName[@]}" ; do
            runGraphman "export --gateway ${GatewayProfile} --using folder --variables.folderPath '${name}' --output '${MigWorkFolder}/${name}.json'"
            outputFileNames+=( "${MigWorkFolder}/${name}.json" )
        done
    fi    

    local combineInputs
    for f in "${outputFileNames[@]}" ; do
        combineInputs=${combineInputs}" --input '${f}'"
    done

    runGraphman "combine ${combineInputs} --output '${MigWorkFolder}/exported.json'"

}

function archive() {
    echo "INFO: archive exported resources"
    dest=$1
    # name="./${dest}/$(hostname)-$(date '+%Y-%m-%d-%H-%M-%S').tar.gz"
    name="./${dest}/$(hostname)-PortalIntModules-$(date '+%Y-%m-%d-%H-%M-%S').tar.gz"

    echo "INFO: archive $name"

    if [ ! -d "${dest}" ] ; then
        mkdir -p "$dest"
    fi

    tar czvf ${name} ${MigWorkFolder}/exported.json ${MigWorkFolder}/*.aar
    echo "INFO: created. ${name}"

    rm /tmp/MIME*.tmp > /dev/null 2>&1
}

function extracting() {
    file=$1
    if [ ! -e "${file}" ] ; then
        echo "ERROR: Please check Filename."
        usages
    fi
    echo "INFO: extract archive file $file"
    if [ -d ${MigWorkFolder} ] ; then
        rm -rf ./${MigWorkFolder}
    fi
    tar xzvf $file -C .

    rm /tmp/MIME*.tmp > /dev/null 2>&1
}

function delete-bundle() {
    echo "INFO: install-bundle "

    runGraphman "import --gateway ${GatewayProfile} --using delete-bundle --input ${MigWorkFolder}/exported.json --options.mappings.folders.action IGNORE"

}


## exclude existing clusterPorperties
function install-bundle() {
    echo "INFO: install-bundle "

    runGraphman "import --gateway ${GatewayProfile} --input ${MigWorkFolder}/exported.json --options.mappings.clusterProperties.action NEW_OR_EXISTING --options.comment \"GraphQL Import : ${Today}\""

}

# function diff() {
#     echo "INFO: diff bundle "

#     runGraphman "diff --gateway ${GatewayProfile} --input ${MigWorkFolder}/exported.json --options.mappings.clusterProperties.action NEW_OR_EXISTING --options.comment \"GraphQL Import : ${Today}\""

# }


case "$job" in
    export)
        export-bundle
        archive archive
        ;;
    extract)
        extracting $2
        ;;
    import-run)
        install-bundle
        ;;
    delete)
        delete-bundle
        ;;
    *)
        usages
        ;;
esac

echo INFO: Started "$startDate" - Ended "$(date)"



#################################################################################
#################################################################################
### etc shell script

########## Export
# echo "Export Portal Integration"

# GatewayProfile=default

# export --gateway ${GatewayProfile} --using clusterProperties --filter.by name --filter.startsWith 'portal.' --output portal_5.2.3-cwp.json

# export --gateway ${GatewayProfile} --using folders --filter.by name --filter.contains 'Portal' --output portal_5.2.3-folder.json

# export --gateway ${GatewayProfile} --using folder --variables.folderPath '/API Portal Integration' --output portal_5.2.3-policies.json

# export --gateway ${GatewayProfile} --using serverModuleFile --variables.name ApiPortalIntegrationAssertion --variables.includeModuleFilePart true --output ApiPortalIntegrationAssertion.json
# export --gateway ${GatewayProfile} --using serverModuleFile --variables.name PortalDeployerAssertion --variables.includeModuleFilePart true --output PortalDeployerAssertion.json
# export --gateway ${GatewayProfile} --using serverModuleFile --variables.name PortalUpgradeAssertion --variables.includeModuleFilePart true --output PortalUpgradeAssertion.json


# combine --input portal_5.2.3-cwp.json --input portal_5.2.3-folder.json --input portal_5.2.3-policies.json \
# --input ApiPortalIntegrationAssertion.json --input PortalDeployerAssertion.json --input PortalUpgradeAssertion.json \
# --output portal_5.2.3_integration.json

########## import

# import --gateway ssg02 --input portal_5.2.3_integration.json --options.comment "graphql-test"
